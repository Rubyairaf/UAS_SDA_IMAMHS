#include <stdio.h>
#include <string.h>

void bubbleSort(char nama[][20], char alamat[][20], int n) {
    int i, j;
    char temp[20];
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (strcmp(nama[j], nama[j + 1]) > 0) {
                strcpy(temp, nama[j]);
                strcpy(nama[j], nama[j + 1]);
                strcpy(nama[j + 1], temp);

                strcpy(temp, alamat[j]);
                strcpy(alamat[j], alamat[j + 1]);
                strcpy(alamat[j + 1], temp);
            }
        }
    }
}

void selectionSort(char nama[][20], char alamat[][20], int n) {
    int i, j, min_idx;
    char temp[20];
    for (i = 0; i < n - 1; i++) {
        min_idx = i;
        for (j = i + 1; j < n; j++) {
            if (strcmp(nama[j], nama[min_idx]) < 0) {
                min_idx = j;
            }
        }
        if (min_idx != i) {
            strcpy(temp, nama[i]);
            strcpy(nama[i], nama[min_idx]);
            strcpy(nama[min_idx], temp);

            strcpy(temp, alamat[i]);
            strcpy(alamat[i], alamat[min_idx]);
            strcpy(alamat[min_idx], temp);
        }
    }
}

int main() {
    char nama[][20] = {"Fahmi", "Romi", "Andri", "Fadilah", "Ruli", "Rudi", "Dendi", "Zaki"};
    char alamat[][20] = {"Jakarta", "Solo", "Jakarta", "Banyuwangi", "Bandung", "Bali", "Purwokerto", "Madiun"};
    int n = sizeof(nama) / sizeof(nama[0]);

    // Bubble Sort
    bubbleSort(nama, alamat, n);
    printf("Hasil Bubble Sort:\n");
    printf("Nama\tAlamat\n");
    for (int i = 0; i < n; i++) {
        printf("%s\t%s\n", nama[i], alamat[i]);
    }

    // Selection Sort
    selectionSort(nama, alamat, n);
    printf("\nHasil Selection Sort:\n");
    printf("Nama\tAlamat\n");
    for (int i = 0; i < n; i++) {
        printf("%s\t%s\n", nama[i], alamat[i]);
    }

    return 0;
}
