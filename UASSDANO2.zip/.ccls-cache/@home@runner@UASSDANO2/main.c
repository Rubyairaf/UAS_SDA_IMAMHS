#include <stdio.h>

void cariLinear(int L[], int N, int X) {
    int found = 0;
    for (int i = 0; i < N; i++) {
        if (L[i] == X) {
            printf("Angka %d ada di indeks ke %d\n", X, i + 1);
            found = 1;
        }
    }

    if (!found) {
        printf("Angka %d tidak ada dalam array\n", X);
    }
}

int main() {
    int array[] = {19, 40, 10, 90, 2, 50, 60, 50, 1};
    int size = sizeof(array) / sizeof(array[0]);

    int input;
    printf("Masukkan angka yang ingin dicari: ");
    scanf("%d", &input);

    cariLinear(array, size, input);

    return 0;
}


